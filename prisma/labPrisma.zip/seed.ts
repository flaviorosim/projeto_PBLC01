import { PrismaClient } from '../generated/prisma';
const prisma = new PrismaClient();

async function main() {
  
  const users = [
    {
      name: "flavio",
      email: "falvio@yahoo.com",
      password: "password123",
      birthDate: new Date("1995-05-10"),
    }];
  
  const profiles = [
    {
      biography: "Traveler and culture lover.",
      userRating: 4.5,
      suggestions: "Visit local museums and restaurants.",
      userId: 1,
    }
  ];
  
  const ratings = [
    {
      grade: 5,
      comment: "Excellent guest!",
      evaluatorId: 2,
      evaluatedId: 1,
    },
    {
      grade: 4,
      comment: "Very kind and clean.",
      evaluatorId: 1,
      evaluatedId: 2,
    },
  ];
  
  const hosts = [
    {
      houseRules: "No smoking indoors.",
    },
  ];
  
  const exchangeStudents = [
    {
      nationality: "Brazilian",
      speakingLanguages: "Portuguese, English",
    },
  ];
  
  const accommodations = [
    {
      description: "Private room in quiet neighborhood",
      capacity: 2,
      hostId: 1,
    },
  ];
  
  const addresses = [
    {
      zipCode: "12345-678",
      country: "Brazil",
      city: "Piquete",
      street: "Rua dos burguers",
      number: 123,
      hostId: 1,
      accommodationId: 1,
    },
  ];
  
  const calendars = [
    {
      availability: [new Date("2025-06-01"), new Date("2025-06-15")],
      hostId: 1,
    },
  ];
  
  const reservations = [
    {
      beginDate: new Date("2025-06-01"),
      endDate: new Date("2025-06-15"),
      status: "confirmed",
      hostId: 1,
      exchangeStudentId: 1,
      calendarId: 1,
    },
  ];
  
  const messages = [
    {
      body: "Hello! Looking forward to the stay.",
      issueDate: new Date("2025-05-01"),
      senderId: 1,
      receiverId: 2,
    },
  ];

  
}

main()
  .then(() => {
    console.log('Seed concluído');
    return prisma.$disconnect();
  })
  .catch((e) => {
    console.error(e);
    return prisma.$disconnect();
  });
